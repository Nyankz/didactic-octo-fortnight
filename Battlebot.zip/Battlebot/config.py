BOT_TOKEN = "8014461182:AAGvAmZ4FzFEKGn_qp5ckKGTp_In6PmyKs0"  # BotFather-дан ал
CHANNEL_ID = -1002590541036      # Батл жарияланатын канал